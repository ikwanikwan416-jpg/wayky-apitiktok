# TikTok Downloader API (Vercel)

API sederhana untuk ambil link video TikTok (tanpa watermark) via [tikwm.com](https://www.tikwm.com).

## Deploy ke Vercel
1. Upload repo ini ke GitHub.
2. Buka [Vercel](https://vercel.com), import repo ini.
3. Deploy → dapat URL API misalnya:
   ```
   https://yourproject.vercel.app/api/download
   ```

## Contoh Request
```bash
curl -X POST https://yourproject.vercel.app/api/download \\
-H "Content-Type: application/json" \\
-d '{"url":"https://www.tiktok.com/@username/video/1234567890"}'
```

## Response
```json
{
  "success": true,
  "video": "https://...",
  "title": "judul video",
  "author": "username"
}
```
