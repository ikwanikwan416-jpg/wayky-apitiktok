const axios = require("axios");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Gunakan metode POST" });
  }

  const { url } = req.body;

  if (!url) {
    return res.status(400).json({ error: "URL TikTok tidak ditemukan." });
  }

  try {
    const apiRes = await axios.post("https://www.tikwm.com/api/", { url });

    if (!apiRes.data || !apiRes.data.data || !apiRes.data.data.play) {
      return res.status(500).json({ error: "Gagal ambil data video." });
    }

    return res.json({
      success: true,
      video: apiRes.data.data.play,
      title: apiRes.data.data.title,
      author: apiRes.data.data.author,
    });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};
